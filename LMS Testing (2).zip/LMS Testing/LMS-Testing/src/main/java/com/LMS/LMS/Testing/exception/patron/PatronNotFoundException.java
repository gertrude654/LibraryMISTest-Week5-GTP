package com.LMS.LMS.Testing.exception.patron;


public class PatronNotFoundException extends RuntimeException {
    public PatronNotFoundException(String message) {
        super(message);
    }
}


