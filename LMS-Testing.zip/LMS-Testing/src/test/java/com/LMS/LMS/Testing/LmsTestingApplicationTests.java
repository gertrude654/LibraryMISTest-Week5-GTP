package com.LMS.LMS.Testing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
